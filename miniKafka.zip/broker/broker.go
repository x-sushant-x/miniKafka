package broker

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"sync"
	"time"

	"github.com/x-sushant-x/miniKafka/config"
	"github.com/x-sushant-x/miniKafka/models"
	"github.com/x-sushant-x/miniKafka/raft"
	"github.com/x-sushant-x/miniKafka/wal/log"

	zerolog "github.com/rs/zerolog/log"
)

type Broker struct {
	id         string
	host       string
	port       string
	topics     sync.Map
	ctx        context.Context
	server     *TCPServer
	raftServer *raft.Server
}

func New(ctx context.Context, port string, raftServer *raft.Server) (*Broker, error) {
	topicsStoragePath := config.Config.TopicsStorageDir
	if topicsStoragePath == "" {
		return nil, ErrEmptyTopicsStorageDir
	}

	broker := Broker{
		port:       port,
		topics:     sync.Map{},
		ctx:        ctx,
		raftServer: raftServer,
	}

	entries, err := os.ReadDir(topicsStoragePath)
	if err != nil {
		if !errors.Is(err, os.ErrNotExist) {
			return nil, err
		}
	}

	if len(entries) > 0 {
		zerolog.Info().Msg("Loading existing topics")
	}

	for _, entry := range entries {
		if !entry.IsDir() {
			continue
		}

		topicName := entry.Name()
		topicPath := filepath.Join(topicsStoragePath, topicName)

		partitions, err := os.ReadDir(topicPath)
		if err != nil {
			return nil, err
		}

		existingTopic, err := log.NewTopic(ctx, topicName, len(partitions), raftServer)
		if err != nil {
			zerolog.Err(err).Str("name", existingTopic.Name).Msgf("Unable to load existing topic")
			return nil, err
		}

		zerolog.Info().Str("name", existingTopic.Name).Msgf("Loaded existing topic")

		broker.topics.Store(topicName, existingTopic)
		zerolog.Info().Str("name", topicName).Int("partitions", len(partitions)).Msg("Loaded topic")
	}

	server, err := NewTCPServer(port)
	if err != nil {
		return nil, err
	}

	broker.server = server
	return &broker, nil
}

func (b *Broker) Start() error {
	zerolog.Info().Str("port", b.port).Msg("Starting TCP Server.")
	go b.startDestroyer()
	return b.server.StartServer(b.handleRequest)
}

func (b *Broker) Produce(topicName string, record *models.Record) (*models.Record, error) {
	if topic, ok := b.topics.Load(topicName); ok {
		return topic.(*log.Topic).Append(record)
	}

	topic, err := log.NewTopic(b.ctx, topicName, 1, b.raftServer)
	if err != nil {
		return nil, log.ErrUnableToCreateTopic
	}

	actual, loaded := b.topics.LoadOrStore(topicName, topic)
	if loaded {
		topic = actual.(*log.Topic)
	}

	return topic.Append(record)
}

func (b *Broker) Consume(topicName string, offset uint64, partition int) (*models.Record, error) {
	if topic, ok := b.topics.Load(topicName); ok {
		return topic.(*log.Topic).Read(offset, partition)
	}

	topic, err := log.NewTopic(b.ctx, topicName, 1, b.raftServer)
	if err != nil {
		return nil, log.ErrUnableToCreateTopic
	}

	actual, loaded := b.topics.LoadOrStore(topicName, topic)
	if loaded {
		topic = actual.(*log.Topic)
	}

	return topic.Read(offset, 1)
}

func (b *Broker) Shutdown() {
	b.server.close()
	b.server.wg.Wait()

	b.topics.Range(func(key, value any) bool {
		topic := value.(*log.Topic)

		if err := topic.Close(); err != nil {
			zerolog.Info().Str("name", topic.Name).Msg("error while closing topic")
		}

		return true
	})
}

func (b *Broker) CreateTopic(topicName string, totalPartitions int) error {
	_, loaded := b.topics.Load(topicName)
	if loaded {
		return log.ErrTopicAlreadyExists
	}

	topic, err := log.NewTopic(b.ctx, topicName, totalPartitions, b.raftServer)
	if err != nil {
		return log.ErrUnableToCreateTopic
	}

	b.topics.Store(topicName, topic)
	return err
}

func (b *Broker) handleRequest(data []byte) ([]byte, error) {
	var req models.Request

	if err := json.Unmarshal(data, &req); err != nil {
		return json.Marshal(models.Response{
			Success: false,
			Error:   err.Error(),
		})
	}

	switch req.Type {

	case "produce":
		record := models.Record{
			Value: []byte(req.Data),
			Key:   []byte(req.Key),
		}

		stored, err := b.Produce(req.Topic, &record)
		if err != nil {
			return json.Marshal(models.Response{
				Success: false,
				Error:   err.Error(),
			})
		}

		return json.Marshal(models.Response{
			Success: true,
			Offset:  stored.Offset,
		})

	case "consume":
		for {
			select {
			case <-b.ctx.Done():
				return json.Marshal(models.Response{
					Success: false,
					Error:   "broker shutting down",
				})

			default:
				record, err := b.Consume(req.Topic, req.Offset, req.Partition)
				if err != nil {
					if errors.Is(err, log.ErrOffsetNotFound) {
						time.Sleep(time.Millisecond * 100)
						continue
					}
				}

				return json.Marshal(models.Response{
					Success: true,
					Data:    string(record.Value),
				})
			}
		}

	case "create_topic":

		err := b.CreateTopic(req.Topic, req.TotalPartitions)
		if err != nil {
			return json.Marshal(models.Response{
				Success: false,
				Error:   err.Error(),
			})
		} else {
			return json.Marshal(models.Response{
				Success: true,
				Error:   "Topic Created",
			})
		}

	default:
		return json.Marshal(models.Response{
			Success: false,
			Error:   "unknown request type",
		})
	}
}

// Destroyer is responsible for deleting old partitions based on retention time. This time is stored in configuration. These are 2 important configurations:
// 1. retention_time_days - Total number of days to keep a segment on disk.
// 2. cleanup_check_interval_seconds - Tells how often to check expired segments and delete them.
func (b *Broker) startDestroyer() {
	ticker := time.NewTicker(time.Duration(config.Config.CleanupCheckIntervalSeconds) * time.Second)

	for {
		select {
		case <-ticker.C:
			b.checkForExpiredSegments()
		case <-b.ctx.Done():
			return
		}
	}
}

func (b *Broker) checkForExpiredSegments() {
	zerolog.Info().Msg("Deleting expired segments")

	b.topics.Range(func(key, value any) bool {
		topic := value.(*log.Topic)
		if err := topic.DeleteExpiredSegments(); err != nil {
			fmt.Println("Error: unable to delete segment.", err)
		}
		return true
	})
}
