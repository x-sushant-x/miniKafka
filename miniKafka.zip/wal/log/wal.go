package log

import (
	"context"
	"os"
	"slices"
	"strconv"
	"strings"
	"sync"
	"time"

	zerolog "github.com/rs/zerolog/log"
	"github.com/x-sushant-x/miniKafka/models"
)

const (
	regularFlushTime = time.Second * 30
)

type wal struct {
	dir      string
	active   *segment
	segments []*segment
	mu       sync.RWMutex
}

func newWAL(ctx context.Context, dir string) (*wal, error) {
	w := &wal{
		dir: dir,
	}

	if err := os.MkdirAll(dir, 0755); err != nil {
		return nil, err
	}

	files, err := os.ReadDir(dir)
	if err != nil {
		return nil, err
	}

	var baseOffsets []uint64

	for _, f := range files {
		if before, ok := strings.CutSuffix(f.Name(), ".store"); ok {
			base := before
			off, err := strconv.ParseUint(base, 10, 64)
			if err != nil {
				return nil, err
			}
			baseOffsets = append(baseOffsets, off)
		}
	}

	slices.Sort(baseOffsets)

	for _, base := range baseOffsets {
		seg, err := newSegment(base, dir)
		if err != nil {
			return nil, err
		}
		w.segments = append(w.segments, seg)
	}

	if len(w.segments) == 0 {
		seg, err := newSegment(0, dir)
		if err != nil {
			return nil, err
		}
		w.segments = []*segment{seg}
	}

	w.active = w.segments[len(w.segments)-1]

	go w.flushRegular(ctx)

	return w, nil
}

func (w *wal) append(record *models.Record) (uint64, error) {
	w.mu.Lock()
	defer w.mu.Unlock()

	if w.active.IsMaxed() {
		if err := w.rotate(); err != nil {
			return 0, err
		}
	}

	return w.active.Append(record)
}

func (w *wal) rotate() error {
	baseOff := w.active.nextOff

	seg, err := newSegment(baseOff, w.dir)
	if err != nil {
		return err
	}

	w.segments = append(w.segments, seg)
	w.active = seg

	return nil
}

func (w *wal) read(offset uint64) (*models.Record, error) {
	w.mu.RLock()
	defer w.mu.RUnlock()

	seg := w.findSegment(offset)
	if seg == nil {
		return nil, ErrOffsetNotFound
	}

	return seg.Read(offset)
}

func (w *wal) findSegment(offset uint64) *segment {
	low := 0
	high := len(w.segments) - 1

	for low <= high {
		mid := (low + high) / 2
		s := w.segments[mid]

		if offset < s.baseOff {
			high = mid - 1
		} else if offset >= s.nextOff {
			low = mid + 1
		} else {
			return s
		}
	}

	return nil
}

func (w *wal) close() error {
	w.mu.Lock()
	defer w.mu.Unlock()

	if err := w.active.index.buf.Flush(); err != nil {
		return err
	}

	if err := w.active.store.buf.Flush(); err != nil {
		return err
	}

	for _, seg := range w.segments {
		if err := seg.Close(); err != nil {
			return err
		}
	}

	return nil
}

func (w *wal) flush() error {
	w.mu.Lock()
	defer w.mu.Unlock()

	err := w.active.index.buf.Flush()
	if err != nil {
		return err
	}

	err = w.active.store.buf.Flush()
	if err != nil {
		return err
	}

	return nil
}

func (w *wal) flushRegular(ctx context.Context) {
	ticker := time.NewTicker(regularFlushTime)
	defer ticker.Stop()

	for {
		select {
		case <-ticker.C:
			zerolog.Info().Msgf("Flushing Data: %s", w.dir)
			if err := w.flush(); err != nil {
				zerolog.Err(err).Msg("wal flush failed")
			}
		case <-ctx.Done():
			return
		}
	}
}

func (w *wal) deleteExpiredSegments() error {
	w.mu.Lock()
	defer w.mu.Unlock()

	var remaining []*segment

	for _, seg := range w.segments {
		if seg == w.active || !seg.IsExpired() {
			remaining = append(remaining, seg)
			continue
		}

		if err := seg.delete(); err != nil {
			return err
		}
	}

	w.segments = remaining
	return nil
}
